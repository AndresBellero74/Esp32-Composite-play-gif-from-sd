#include <Arduino.h>
/*

Example application of ESP_8_BIT color composite video generator library on ESP32.
Connect GPIO25 to signal line, usually the center of composite video plug.

Plays an animated GIF using the AnimatedGIF library by Larry Bank [bitbank2]
https://github.com/bitbank2/AnimatedGIF

Lightly modified from AnimatedGIF library's example "ESP32_LEDMatrix_I2S"

AnimatedGIF library and example was released under Apache 2.0 license.
https://github.com/bitbank2/AnimatedGIF/blob/master/LICENSE

Cat and Galactic Squid friend by Emily Velasco
https://twitter.com/MLE_Online/status/1393660363191717888
Released under Creative Commons Attribution-ShareAlike (CC BY-SA 4.0) license
https://creativecommons.org/licenses/by-sa/4.0/

Converted to byte array via Unix/Linux command line utility xxd

  xxd -i cat_and_galactic_squid.gif cat_and_galactic_squid.h

Then manually adding 'const' to move it out of precious dynamic memory

*/

#include <AnimatedGIF.h>
#include <ESP_8_BIT_GFX.h>
//#include "cat_and_galactic_squid.h"
#include <SD.h>
#define PIN_SD_CS 21 // D8 
#define PIN_SD_MISO 19 //12
#define PIN_SD_MOSI 23 //11
#define PIN_SD_SCLK 18 //10
int BUFFER_SIZE = 24;
uint8_t FileGif [61440];
File root;
// Create an instance of the graphics library
ESP_8_BIT_GFX videoOut(true /* = NTSC */, 16 /* = RGB565 colors will be downsampled to 8-bit RGB332 */);
AnimatedGIF gif;

// Vertical margin to compensate for aspect ratio
const int margin = 29;

// Draw a line of image to ESP_8_BIT_GFX frame buffer
void GIFDraw(GIFDRAW *pDraw)
{
    uint8_t *s;
    uint16_t *d, *usPalette, usTemp[320];
    int x, y;

    usPalette = pDraw->pPalette;
    y = pDraw->iY + pDraw->y; // current line

    s = pDraw->pPixels;
    if (pDraw->ucDisposalMethod == 2) // restore to background color
    {
      for (x=0; x<pDraw->iWidth; x++)
      {
        if (s[x] == pDraw->ucTransparent)
           s[x] = pDraw->ucBackground;
      }
      pDraw->ucHasTransparency = 0;
    }
    // Apply the new pixels to the main image
    if (pDraw->ucHasTransparency) // if transparency used
    {
      uint8_t *pEnd, c, ucTransparent = pDraw->ucTransparent;
      int x, iCount;
      pEnd = s + pDraw->iWidth;
      x = 0;
      iCount = 0; // count non-transparent pixels
      while(x < pDraw->iWidth)
      {
        c = ucTransparent-1;
        d = usTemp;
        while (c != ucTransparent && s < pEnd)
        {
          c = *s++;
          if (c == ucTransparent) // done, stop
          {
            s--; // back up to treat it like transparent
          }
          else // opaque
          {
             *d++ = usPalette[c];
             iCount++;
          }
        } // while looking for opaque pixels
        if (iCount) // any opaque pixels?
        {
          for(int xOffset = 0; xOffset < iCount; xOffset++ ){
            videoOut.drawPixel(pDraw->iX + x + xOffset, margin + y, usTemp[xOffset]);
          }
          x += iCount;
          iCount = 0;
        }
        // no, look for a run of transparent pixels
        c = ucTransparent;
        while (c == ucTransparent && s < pEnd)
        {
          c = *s++;
          if (c == ucTransparent)
             iCount++;
          else
             s--;
        }
        if (iCount)
        {
          x += iCount; // skip these
          iCount = 0;
        }
      }
    }
    else
    {
      s = pDraw->pPixels;
      // Translate the 8-bit pixels through the RGB565 palette (already byte reversed)
      for (x=0; x<pDraw->iWidth; x++)
      {
        videoOut.drawPixel(x,margin + y, usPalette[*s++]);
      }
    }
} /* GIFDraw() */


void setup() {
  Serial.begin(9600);
  videoOut.begin();
  videoOut.copyAfterSwap = true; // gif library depends on data from previous buffer
  videoOut.fillScreen(0);
  videoOut.waitForFrame();

  gif.begin(LITTLE_ENDIAN_PIXELS);

  Serial.print("Initializing SD card...");
  if (!SD.begin(PIN_SD_CS)){ //, SD_MOSI, SD_MISO, SD_SCLK)) {
    Serial.println("failed!");
    while(1);  // stay here
  }
  Serial.println("OK!"); 
 
}
void loop() {
  uint8_t ret;
  uint32_t start;
  File root = SD.open("/");  // open SD card main root
 
  while (true) {
    File entry =  root.openNextFile();  // open file
 
    if (! entry) {
      // no more files
      root.close();
      return;
    }
 
    uint8_t nameSize = String(entry.name()).length();  // get file name size
    String str1 = String(entry.name()).substring( nameSize - 4 );  // save the last 4 characters (file extension)
    Serial.println(entry.name());
    if ( str1.equalsIgnoreCase(".gif") ) {  // if the file has '.bmp' extension
      int intFile = 0;
      File dataFile = SD.open(entry.name()); 
      if (dataFile){
        uint8_t dataLine[BUFFER_SIZE];
        while (dataFile.available()){
          dataFile.read(dataLine, BUFFER_SIZE);
          for ( int i=0; i < BUFFER_SIZE; i++){
            FileGif[intFile + i] = dataLine[i];
          }
          intFile = intFile + BUFFER_SIZE;
        }
        dataFile.close();
      }
      else {
        Serial.println(F("Error al abrir el archivo"));
      }
      if (intFile > 0){
        if (gif.open(FileGif, intFile, GIFDraw)){
            while (gif.playFrame(true, NULL)){
              videoOut.waitForFrame();
            }
            videoOut.waitForFrame();
            gif.close();   
        }
        delay(5000);
      }
    }
    
    entry.close();  // close the file
    delay(500);
  }
}