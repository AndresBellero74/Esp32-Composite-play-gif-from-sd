This is a collection of 207 GIF files made by Cyriak Harris.

Animated GIFs by Cyriak Harris is licensed under CC BY-NC-SA 4.0

http://www.cyriak.co.uk
http://www.cyriak.co.uk/animation/contact
info@cyriak.co.uk

Usage:

- Download archive from https://github.com/bitbank2/AnimatedGIF/releases/download/1.0.1/Gif_Animations_By_Cyriak_Harris.zip
- Unzip it to your SD Card
- Insert the SD Card in your ESP32
- Flash the sketch
